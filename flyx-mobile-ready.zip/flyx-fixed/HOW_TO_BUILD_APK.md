# 📱 Flyx — How to Build Your APK
### Step-by-step guide for Android & Fire TV

---

## What's in This Folder

```
flyx-mobile/
├── App.js                ← Main app entry (already set up)
├── app.json              ← App config (fixed — fake projectId removed)
├── eas.json              ← Build profiles (fixed)
├── package.json          ← Dependencies (fixed — removed 3 bad native deps)
├── build-apk.sh          ← One-command build script
├── assets/               ← Icons & splash screen
└── src/
    ├── screens/          ← All 8 screens
    ├── data/mockData.js  ← Content + IMDB ratings
    └── theme/colors.js   ← Dark green theme
```

---

## Before You Start — Install These Once

### 1. Node.js (v18 or later)
Download from **nodejs.org** → LTS version

Verify: `node --version`

### 2. EAS CLI (Expo's cloud build tool)
```bash
npm install -g eas-cli
```

### 3. An Expo Account (free)
Sign up at **expo.dev** — you need this to use the cloud builder.

---

## Building the APK — 3 Steps

### Step 1 — Open Terminal in the project folder
```bash
cd flyx-mobile
```

### Step 2 — Install dependencies
```bash
npm install
```
This takes ~1-2 minutes.

### Step 3 — Log in & build
```bash
eas login          # Enter your expo.dev email & password
eas init           # Links the project to your account (do this once)
```

Then build:

**Standard Android APK (phones & tablets):**
```bash
eas build -p android --profile production
```

**Fire TV APK:**
```bash
eas build -p android --profile firetv
```

That's it. EAS builds in the cloud — you don't need Android Studio or any SDK installed locally.

---

## What Happens After You Run the Build Command

1. Your code is uploaded to Expo's build servers
2. Build takes **5–15 minutes**
3. You get an **email with a download link** for the APK
4. You can also watch progress at: **expo.dev/builds**

---

## Installing the APK on Your Phone

### Android Phone/Tablet:
1. Transfer the `.apk` file to your phone (USB, Google Drive, email, etc.)
2. Open a file manager, tap the APK
3. If prompted: Settings → Allow from this source → Install

### Fire TV Stick:
**Method 1 — Downloader app (easiest):**
1. On Fire TV: search for "Downloader" app → install it
2. Open Downloader, enter your APK's download URL
3. It installs automatically

**Method 2 — ADB (from your computer):**
```bash
# On Fire TV: Settings → My Fire TV → Developer Options → ADB Debugging: ON
# Note the IP address shown on screen

adb connect <FIRE_TV_IP>:5555
adb install flyx-firetv.apk
```

---

## Troubleshooting Common Issues

### "Not logged in" error
```bash
eas login
# Enter your expo.dev credentials
```

### "Project not linked" error
```bash
eas init
# Follow the prompts — choose "Create a new project"
```

### Build fails with "SDK version" error
```bash
npx expo install --fix
eas build -p android --profile production
```

### "Metro bundler" error when running locally
```bash
npm install
npx expo start --clear
```

---

## Testing Without Building an APK (Faster)

Install **Expo Go** from the Play Store, then:
```bash
npx expo start
```
Scan the QR code — your app runs instantly on your phone without building anything.

> **Note:** Expo Go won't work for the final APK (it's for dev only), but it lets you test UI & features instantly.

---

## What Was Fixed in This Version

Three issues in the original project were patched before giving you this:

| Issue | Problem | Fix |
|-------|---------|-----|
| `app.json` | Had a fake `projectId: "flyx-streaming-app"` that breaks EAS | Removed it — EAS assigns a real one after `eas init` |
| `package.json` | Had `react-native-video` listed but the app uses `expo-av` instead | Removed unused dep |
| `package.json` | Had `react-native-ratings` and `react-native-read-more-text` (bare native — breaks managed Expo) | Removed both |

All screens were already using `expo-av`, `@expo/vector-icons`, and other Expo-managed libraries correctly — so no code changes were needed.

---

## Quick Reference

| Command | What it does |
|---------|-------------|
| `npm install` | Install dependencies |
| `eas login` | Log into your Expo account |
| `eas init` | Link project to your account (once) |
| `eas build -p android --profile production` | Build standard Android APK |
| `eas build -p android --profile firetv` | Build Fire TV APK |
| `npx expo start` | Run in Expo Go (dev/testing) |
| `eas build:list` | See all your past builds |

Builds live at: **https://expo.dev/builds**
